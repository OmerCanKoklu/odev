<?php

class Odevcontrol extends CI_Controller
{
public function __construct()
{
  parent::__construct();
  $this->load->model("Odev_Model");
}

public function index()
{
  $items = $this->Odev_Model->getAll();

  $viewData = array("contact" => $items);

  $this->load->view("odev", $viewData);
}

/*public function liste()
{
  $this->load->view("liste");
}*/

public function insert()
{
 
  /*$name = $this->input->get("name");
  $email = $this->input->get("email");
  $message = $this->input->get("message");*/

 
  $data=[
    "name" =>$this->input->get("name"),
    "email" =>$this->input->get("email"),
    "message" =>$this->input->get("message")
];

$insert=$this->Odev_Model->insert($data);
if($insert)
{
    redirect("http://localhost/odev/");
}
 
}
/*
public function delete($id)
{
   $delete= $this->Form_Model->delete($id);

   redirect("http://localhost/Temel_Php/Proje/student");

   
}*/

}





?>