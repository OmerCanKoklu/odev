<?php

class Listecontrol extends CI_Controller
{
public function __construct()
{
  parent::__construct();
  $this->load->model("Liste_Model");
}

public function index()
{
  $items = $this->Liste_Model->getAll();

  $viewData = array("contact" => $items);

  $this->load->view("liste", $viewData);
}

/*public function liste()
{
  $this->load->view("liste");
}*/

public function insert()
{
 
  /*$name = $this->input->get("name");
  $email = $this->input->get("email");
  $message = $this->input->get("message");*/

 
  $data=[
    "name" =>$this->input->post("name"),
    "email" =>$this->input->post("email"),
    "message" =>$this->input->post("message")
];

$insert=$this->Odev_Model->insert($data);
if($insert)
{
    redirect("http://localhost/odev/");
}
 
}
/*
public function delete($id)
{
   $delete= $this->Form_Model->delete($id);

   redirect("http://localhost/Temel_Php/Proje/student");

   
}*/

}
