<!DOCTYPE html>
<html lang="en">

<body>


<div class="wrapper">
			<div class="inner">
			<form action="http://localhost/odev/listecontrol/"><button>LİSTE <i class="zmdi zmdi-arrow-right"></i></button></form>
				<form action="Odevcontrol/insert">
				<br>
					<h3>İLETİŞİM</h3>
					<br>
					<label class="form-group">
						<input id="name" name="name" type="text" class="form-control">
						<span>İsminiz</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input name="email" id="email" type="text" class="form-control">
						<span for="">Mail Adresiniz</span>
						<span class="border"></span>
					</label>
					<label class="form-group" >
						<textarea name="message" id="message" class="form-control"></textarea>
						<span for="">Mesajınız</span>
						<span class="border"></span>
					</label>
					<button>Gönder 
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>


		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">


		
</body>
</html>
