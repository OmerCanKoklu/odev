<!DOCTYPE html>
<html lang="en">

<body>


    <div class="wrapper">
        <div class="inner">
            <form action="http://localhost/odev/"><button>İLETİŞİM<i class="zmdi zmdi-arrow-right"></i></button></form>

                <br><br><br><br>

            <table class="table"  border="1" cellpadding=30 >
                <thead>
                    <tr>
                        <th  scope="col">Id</th>
                        <th scope="col">Ad</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Mesaj</th>
                    </tr>

                </thead>
                <tbody>

                        <?php foreach ($contact as $items) { ?>
                    <tr>
                        <th><?php echo $items->id; ?> </th>
                        <th><?php echo $items->name; ?> </th>
                        <th><?php echo $items->email; ?> </th>
                        <th><?php echo $items->message; ?> </th>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>


    <link rel="stylesheet" href="../fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

    <!-- STYLE CSS -->
    <link rel="stylesheet" href="../css/style.css">



</body>

</html>